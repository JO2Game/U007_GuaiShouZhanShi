import egame.terminal.usersdk.CallBackListener;
import egame.terminal.usersdk.EgameUser;
import egame.terminal.usersdk.ErrorCode;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/*
 * FileName:	DemoActivity.java
 * Copyright:	炫彩互动网络科技有限公司
 * Author: 		DELL
 * Description:	<文件描述>
 * History:		2015年2月6日 1.00 初始版本
 */

/**
 * 本类实例是处理非继承EgameUserActvity类的案列
 * 
 * 
 * @author  
 */
public class DemoActivity extends Activity {
    
     
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    
    
     
    @Override
    protected void onPause() {
        EgameUser.onPause(DemoActivity.this);
        super.onPause();
    }
    
    
     
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(ErrorCode.TOEKN_INVALID==resultCode){//在此处捕获返回码，触发登陆
            startLogin();
        }
        super.onActivityResult(requestCode, resultCode, data);
    } 
    
    
    @Override
    protected void onResume() {
        EgameUser.onResum(DemoActivity.this);
        super.onResume();
    }
    
    
    private void startLogin(){
        EgameUser.start(DemoActivity.this, 12345, new CallBackListener() {
            
            @Override
            public void onSuccess(String code) {
                
            }
            
            @Override
            public void onFailed(int code) {
                
            }
            
            @Override
            public void onCancel() {
                
            }
        });
    }
}
