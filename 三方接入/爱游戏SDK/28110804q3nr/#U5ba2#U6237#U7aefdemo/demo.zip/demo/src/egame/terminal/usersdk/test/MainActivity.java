﻿/*
 * FileName:    MainActivity.java
 * Copyright:   炫彩互动网络科技有限公司
 * Author:      Hein
 * Description: 演示DEMO
 * History:     2014-06-18 1.00 初始版本
 */
package egame.terminal.usersdk.test;

import com.test.sdktest.MainActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import egame.terminal.usersdk.CallBackListener;
import egame.terminal.usersdk.EgameUser;
import egame.terminal.usersdk.R;

/**
 * 
 * 演示DEMO
 * 
 * @author 
 */
public class MainActivity extends EgameUserActivity implements View.OnClickListener {

    /**
     * 游戏的clientId
     */
//    private static final int CLIENT_ID = 84106431;
    private static final int CLIENT_ID = 51551648;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test_activity_main);

        findViewById(R.id.egame_test_login).setOnClickListener(this);
        findViewById(R.id.egame_test_gettoken).setOnClickListener(this);

        // 启动用户SDK登陆流程
        initLogin();
    }

    /**
     * 
     * 启动用户SDK登陆流程
     */
    @Override
    public void initLogin() {
        EgameUser.start(this, CLIENT_ID,new CallBackListener() {
            
            @Override
            public void onSuccess(String code) {
                //此处返回授权码，需要自行换取token
            }
            
            @Override
            public void onFailed(int code) {
                
            }
            
            @Override
            public void onCancel() {
                if(!EgameUser.getLoginWindowState()){
                    Toast.makeText(MainActivity.this, "登陆窗消失", 0).show();
                }else{
                    Toast.makeText(MainActivity.this, "取消登录", 0).show();
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.egame_test_login) { // 启动用户SDK登陆流程
            initLogin();
        }
    }
    
}
